touch  estimate_Youcha.sh  &&  cat  estimate_Youcha.sh && \
export PATH=/share/public/software/paml4.9e/bin:${PATH} && \
mcmctree mcmctree.ctl && \
mv out.BV in.BV && \
touch estimate_Youcha.tmp && \
mv  estimate_Youcha.tmp  estimate_Youcha && \
sleep 10
