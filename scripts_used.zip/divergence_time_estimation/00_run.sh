perl aln2phy.pl supergene.protein.fa.aln cha.phy
