export PATH=/share/public/software/paml4.9e/bin:${PATH} && \
codeml codeml.ctl
