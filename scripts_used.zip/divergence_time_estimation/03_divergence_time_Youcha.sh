touch  divergence_time_Youcha.sh  &&  cat  divergence_time_Youcha.sh && \
export PATH=/share/public/software/paml4.9e/bin:${PATH} && \
perl change_rgene_gamma.pl ../01codeml/mlb mcmctree.ctl >mcmctree_n.ctl && \
cp ../02mcmctree/in.BV ./ && \
mcmctree mcmctree_n.ctl && \
perl tree.pl divergence_time_Youcha tree.desc Youcha && \
touch divergence_time_Youcha.tmp && \
mv  divergence_time_Youcha.tmp  divergence_time_Youcha && \
sleep 10
