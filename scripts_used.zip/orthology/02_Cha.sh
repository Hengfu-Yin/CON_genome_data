cat ama.out ara.out via.out cas.out cis.out poa.out youcha.out acs.out dii.out> Cha.all.blast_result && \
mkdir Fasta && mv *.fasta Fasta && \
/orthomclSoftware-v2.0.9/bin/orthomclInstallSchema mysql.config  orthomcl.log && \
/orthomclSoftware-v2.0.9/bin/orthomclBlastParser Cha.all.blast_result Fasta >> similarSequences.txt && \
/orthomclSoftware-v2.0.9/bin/orthomclLoadBlast mysql.config similarSequences.txt && \
/orthomclSoftware-v2.0.9/bin/orthomclPairs mysql.config orthomcl.log cleanup=no && \
/orthomclSoftware-v2.0.9/bin/orthomclDumpPairsFiles mysql.config && \
/MCL/bin/mcl mclInput --abc -o result.out -I 1.5 && \
cat result.out | /orthomclSoftware-v2.0.9/bin/orthomclMclToGroups GROUP 1 > Cha.temp.group.xls && \
perl format_output.pl -i Cha.temp.group.xls -o Cha.group.xls -t orthomcl && \
perl reformat_4R.pl ama,ara,via,cas,cis,poa,youcha,acs,dii Cha.group.xls Cha.4r && \
Rscript Protein_Fam.plot.R -i  Cha.4r -n ama,ara,via,cas,cis,poa,youcha,acs,dii -o Cha.venn.diagram.png
