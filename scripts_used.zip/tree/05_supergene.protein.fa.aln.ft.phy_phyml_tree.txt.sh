#cp ../03fa2phylip/supergene.protein.fa.aln.ft.phy . && \
java -jar /prottest/prottest-3.4.2/prottest-3.4.2.jar -i supergene.protein.fa.aln.ft.phy -I -G -IG -F -AIC -ncat 8 -all -threads 40 -o supergene.protein.fa.aln.ft.phy.model && \
perl buildTree.pl supergene.protein.fa.aln.ft.phy.model supergene.protein.fa.aln.ft.phy && \
Rscript drawtree.R --infile supergene.protein.fa.aln.ft.phy_phyml_tree.txt --outfile supergene.protein.fa.aln.ft.phy_phyml_tree.txt.fig && \
mv supergene.protein.fa.aln.ft.phy_phyml_tree.txt supergene.protein.fa.aln.ft.phy_phyml_tree.txt.tmp && \
mv  supergene.protein.fa.aln.ft.phy_phyml_tree.txt.tmp  supergene.protein.fa.aln.ft.phy_phyml_tree.txt && \
sleep 10
