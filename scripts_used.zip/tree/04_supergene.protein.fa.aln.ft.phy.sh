perl fasta2phylip.pl supergene.protein.fa.aln.ft supergene.protein.fa.aln.ft.phy.tmp && \
mv  supergene.protein.fa.aln.ft.phy.tmp  supergene.protein.fa.aln.ft.phy && \
sleep 10
