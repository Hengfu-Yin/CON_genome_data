perl findSingleCopy.pl Cha.group.xls 9 Cha.all.fasta && \
mv  supergene.protein.fa.tmp  supergene.protein.fa && \
sleep 10
