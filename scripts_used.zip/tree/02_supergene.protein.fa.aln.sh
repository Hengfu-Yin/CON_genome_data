/mafft/mafft-7.310-with-extensions/bin/mafft --auto --anysymbol --thread 30 supergene.protein.fa >supergene.protein.fa.aln.tmp && \
mv  supergene.protein.fa.aln.tmp  supergene.protein.fa.aln && \
sleep 10
