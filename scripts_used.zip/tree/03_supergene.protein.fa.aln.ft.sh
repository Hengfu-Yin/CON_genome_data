#cp ../01mafft/supergene.protein.fa.aln . && \
/Gblocks/Gblocks_0.91b/Gblocks supergene.protein.fa.aln -t=p -e=.ft -b4=5 -d=y || ls > /dev/null && \
mv supergene.protein.fa.aln.ft supergene.protein.fa.aln.ft.tmp && \
mv  supergene.protein.fa.aln.ft.tmp  supergene.protein.fa.aln.ft && \
sleep 10
