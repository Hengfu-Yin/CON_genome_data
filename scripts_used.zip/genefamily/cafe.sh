#!/share/public/software/cafehahnlab-code3.1/cafe/cafe
version
date
load -i youcha.cafe -p 0.05 -t 10 -l log.txt

tree (((((Ca.sinensis:0.173371,C.oleifera:0.173371):0.588068,A.chinensis:0.761439):0.126201,D.kaki:0.887640):0.648653,(V.vinifera:1.379791,(P.trichocarpa:1.125688,(A.thaliana:0.992879,Ci.sinensis:0.992879):0.132809):0.254103):0.156503):0.316410,A.trichopoda:1.852704)

## lambda -s -t (3,((2,(2,2)2)2,(2,((1,1)1,(1,1)1)1)2)3)
#lambda -s -t (1,((1,(1,1)1)1,(1,((1,1)1,(1,1)1)1)1)1)
lambda -s -t (((((1,1)1,1)1,1)1,(1,(1,(1,1)1)1)1)1,1)

report resultfile

date
