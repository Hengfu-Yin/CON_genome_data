perl orthomcl2cafe.pl -o Cha.group.xls -c youcha.cafe -t tree.desc youcha && \
./cafe.sh && \
python /CAFE/python_scripts/cafetutorial_report_analysis.py -i resultfile.cafe -o ./youcha && \
perl tiny.pl youcha_fams.txt mcmc.2.tre >f.txt 2>err && \
Rscripts plot.R

