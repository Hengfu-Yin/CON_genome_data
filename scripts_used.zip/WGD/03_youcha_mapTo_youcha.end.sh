minAlnLength=50 && \
perl blast2matchList.pl youcha_mapTo_youcha.blastp.outfmt11to6  ${minAlnLength}  1e-5  youcha.transid2pos  youcha.transid2pos  youcha_mapTo_youcha.matchList && \
export HOSTTYPE=x86_64 && \
filter=filter_repetitive_matches.pl && \
perl $filter 50000 < youcha_mapTo_youcha.matchList > youcha_mapTo_youcha.matchList.filtered && \
chainer=/DAGCHAINER/run_DAG_chainer.pl && \
perl $chainer -i youcha_mapTo_youcha.matchList.filtered -s -I && \
touch youcha_mapTo_youcha.end.tmp && \
mv  youcha_mapTo_youcha.end.tmp  youcha_mapTo_youcha.end && \
sleep 10
