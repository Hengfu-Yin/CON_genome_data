export PATH=/ncbi-blast-2.6.0+-src/c++/ReleaseMT/bin/:${PATH} && \
blastp  -outfmt  11  -num_threads  16  -evalue  1e-5  -num_alignments  15  -max_hsps  1  -db youcha.longest.pep.fa   -query youcha.longest.pep.fa  -out youcha_mapTo_youcha.blastp.outfmt11 && \
blast_formatter -num_alignments 11  -outfmt 6 -archive youcha_mapTo_youcha.blastp.outfmt11  -out  youcha_mapTo_youcha.blastp.outfmt11to6 && \
touch youcha_mapTo_youcha.end.tmp && \
mv  youcha_mapTo_youcha.end.tmp  youcha_mapTo_youcha.end && \
sleep 10
