#!/bin/bash
export PATH=$PATH:/ParaAT2.0/:$PATH && \
export PATH=$PATH:/blast/blast-2.6.0/ncbi-blast-2.6.0+/bin:$PATH && \
export PATH=$PATH:/KaKs_Calculator2.0/bin/Linux/:$PATH && \
Species1=youcha && \
Species2=coffee && \
makeblastdb -in ${Species2}.pep -dbtype prot && \
blastp -query ${Species1}.pep -db ${Species2}.pep -evalue 1e-5 -max_target_seqs 1 -num_threads 10 -out ${Species1}2${Species2}.blastp_out.m6 -outfmt 6 && \
cut -f1-2 ${Species1}2${Species2}.blastp_out.m6|sort|uniq > ${Species1}2${Species2}.homolog && \
cat ${Species1}.cds ${Species2}.cds >${Species1}_${Species2}.cds && \
cat ${Species1}.pep ${Species2}.pep >${Species1}_${Species2}.pep && \
perl ParaAT.pl -h ${Species1}2${Species2}.homolog -n ${Species1}_${Species2}.cds -a ${Species1}_${Species2}.pep -p proc -m clustalw2 -f axt -o ${Species1}2${Species2}_out && \ 
cd ${Species1}2${Species2}_out && \
for i in `ls *.axt`;do KaKs_Calculator -i $i -o ${i}.kaks -m YN;done && \
for i in `ls *.axt`;do python axt2one-line.py $i ${i}.one-line;done && \
ls *.one-line|while read id;do perl calculate_4DTV_correction.pl $id >${id%%one-line}4dtv;done && \
for i in `ls *.4dtv`;do awk 'NR>1{print $1"\t"$2}' $i >>all-4dtv.txt;done && \
for i in `ls *.kaks`;do awk 'NR>1{print $1"\t"$3"\t"$4"\t"$5}' $i >>all-kaks.txt;done && \
sort all-4dtv.txt|uniq >all-4dtv.results && \
sort all-kaks.txt|uniq >all-kaks.results && \
join -1 1 -2 1 all-kaks.results all-4dtv.results >all-results.txt && \
sed -i '1i\Seq\tKa\tKs\tKa/Ks\t4dtv_corrected' all-results.txt
