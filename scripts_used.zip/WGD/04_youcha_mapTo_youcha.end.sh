export PATH=/WDLIB/python2.7.13/bin/:${PATH} && \
export PATH=/bio-pipeline/synonymous_calculation/bin/:${PATH} && \
export PATH=/pal2nal.v14/:${PATH} && \
export PATH=/glibc/2.14/bin/:${PATH} && \
export PATH=/samtools-0.1.19/:${PATH} && \
export LD_LIBRARY_PATH=/glibc/2.14/lib/:${LD_LIBRARY_PATH} && \
grep -v -E "^##" youcha_mapTo_youcha.matchList.filtered.aligncoords | cut -f 2,6 > paralogous.pairs && \
cat youcha.longest.pep.fa > all.pep.fa && \
samtools faidx all.pep.fa && \
cat youcha.longest.cds.fa > all.cds.fa && \
samtools faidx all.cds.fa && \
## extract && \
cat paralogous.pairs | xargs samtools faidx all.pep.fa  > paralogous.pep && \
cat paralogous.pairs | xargs samtools faidx all.cds.fa  > paralogous.cds && \
bin=/bio-pipeline/synonymous_calculation/synonymous_calc.py && \
python $bin paralogous.pep  paralogous.cds > youcha_mapTo_youcha.ks && \
Rscript  /share/work2/huangjw/scripts/assemble/WGD/scripts/plot_single_ks.R  youcha_mapTo_youcha.ks  youcha_mapTo_youcha  youcha_mapTo_youcha.png && \
touch youcha_mapTo_youcha.end.tmp && \
mv  youcha_mapTo_youcha.end.tmp  youcha_mapTo_youcha.end && \
sleep 10
