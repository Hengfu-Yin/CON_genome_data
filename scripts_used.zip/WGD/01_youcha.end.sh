minProteinLen=50 && \
prefix=youcha && \
## env && \
export PATH=/UCSCtools/:${PATH} && \
export PATH=/samtools-0.1.19/:${PATH} && \
export PATH=/bedtools2/bin/:${PATH} && \
export PATH=/ncbi-blast-2.6.0+-src/c++/ReleaseMT/bin/:${PATH} && \
## process gff && \
gff3ToGenePred  -warnAndContinue  -geneNameAttr=gene_id  -rnaNameAttr=tran_id Chrall.genes_new.gff  ${prefix}.refGene.txt && \
cut -f 1,12 ${prefix}.refGene.txt > ${prefix}.transid2geneid && \
cut -f 1,2,4  ${prefix}.refGene.txt   | sort -k2,2 -k3,3n | awk '{printf("%s\t%s\t%d\t%d\t%d\n", $1, $2, ++a[$2], a[$2], $3 ) }' > ${prefix}.transid2sn && \
cut -f 1,2,4,5 ${prefix}.refGene.txt | awk '{printf("%s\t%s\t%s\t%s\n", $1, $2, $3, $4)}'  > ${prefix}.transid2pos && \
## && \
genePredToGtf file ${prefix}.refGene.txt  ${prefix}.gtf && \
perl gtf2bed.pl  ${prefix}.gtf  ${prefix}.bed && \
bedtools  getfasta  -fi final.fa  -bed  ${prefix}.bed  -fo ${prefix}.cds.fa  -s  -name -split && \
sed -i  '/^>/ {s/([+-])//}'  ${prefix}.cds.fa && \
samtools faidx ${prefix}.cds.fa && \
## translate cds to pep && \
/EMBOSS-6.6.0/bin/transeq  -sequence  ${prefix}.cds.fa   -outseq  ${prefix}.pep.fa && \
sed -i '/^>/ {s/_[0-9]*$//}' ${prefix}.pep.fa && \
samtools faidx ${prefix}.pep.fa && \
awk 'ARGIND==1 {pep[$1]=$2}  ARGIND>1 && ($1 in pep) {printf("%s\t%s\n", $1,pep[$1])}' ${prefix}.pep.fa.fai  ${prefix}.cds.fa.fai  > ${prefix}.preparePepLength && \
awk -F '\t' 'ARGIND==1 {prot[$1]=$2}  ARGIND>1 && ($1 in prot) {printf("%s\t%s\n", $0,prot[$1])}' ${prefix}.preparePepLength   ${prefix}.transid2geneid | sort -k2,2 -k3,3nr -k1,1 > ${prefix}.pepLength2geneid && \
awk '!x[$2]++{print}' ${prefix}.pepLength2geneid > ${prefix}.longestPep2geneid && \
awk -F '\t' -v min="${minProteinLen}"  '{if($3 > minProteinLen)print $1}' ${prefix}.longestPep2geneid | xargs samtools faidx  ${prefix}.pep.fa > ${prefix}.longest.pep.fa && \
awk -F '\t' -v min="${minProteinLen}"  '{if($3 > minProteinLen)print $1}' ${prefix}.longestPep2geneid | xargs samtools faidx  ${prefix}.cds.fa > ${prefix}.longest.cds.fa && \
## makeblastdb for longest protein fasta && \
makeblastdb -in ${prefix}.longest.pep.fa -parse_seqids -dbtype prot && \
touch youcha.end.tmp && \
mv  youcha.end.tmp  youcha.end && \
sleep 10
