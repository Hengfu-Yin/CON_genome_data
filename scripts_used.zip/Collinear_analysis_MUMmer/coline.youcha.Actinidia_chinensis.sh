

/MUMmer3.23/nucmer  -g  1000  --prefix=youcha.Actinidia_chinensis.nucmer  Kiwifruit_pseudomolecule.fa  final.fa && \

/MUMmer3.23/delta-filter  -r  -q  -l  200  youcha.Actinidia_chinensis.nucmer.delta  >  youcha.Actinidia_chinensis.nucmer.filter && \

/MUMmer3.23/show-coords  -rcloT  youcha.Actinidia_chinensis.nucmer.delta   >  youcha.Actinidia_chinensis.nucmer.delta.coords && \

/MUMmer3.23/show-coords  -rcloT  youcha.Actinidia_chinensis.nucmer.filter  >  youcha.Actinidia_chinensis.nucmer.filter.coords && \

/MUMmer3.23/mummerplot  --png  --large  --layout  youcha.Actinidia_chinensis.nucmer.delta   -p  youcha.Actinidia_chinensis.nucmer.delta   -R  /share/science/Denovo/BBFC2018184/analysis/data/protein/Actinidia_chinensis/Kiwifruit_pseudomolecule.fa  -Q  /share/science/Denovo/BBFC2018184/assembly/HIC_3ddna/HiC_10X/analysis/youcha/analysis/assembly.repeatcoverage_15/final/final.fa && \

/MUMmer3.23/mummerplot  --png  --large  --layout  youcha.Actinidia_chinensis.nucmer.filter  -p  youcha.Actinidia_chinensis.nucmer.filter  -R  /share/science/Denovo/BBFC2018184/analysis/data/protein/Actinidia_chinensis/Kiwifruit_pseudomolecule.fa  -Q  /share/science/Denovo/BBFC2018184/assembly/HIC_3ddna/HiC_10X/analysis/youcha/analysis/assembly.repeatcoverage_15/final/final.fa && \

Rscript coline_plot.R -i youcha.Actinidia_chinensis.nucmer.delta.coords  -o youcha.Actinidia_chinensis.delta && \

Rscript coline_plot.R -i youcha.Actinidia_chinensis.nucmer.filter.coords -o youcha.Actinidia_chinensis.filter && \

/MUMmer3.23/show-snps  -CIlrT  youcha.Actinidia_chinensis.nucmer.filter  > coline-youcha.Actinidia_chinensis.nucmer.snp && \

touch coline.youcha.Actinidia_chinensis.end && \

sleep 10 
